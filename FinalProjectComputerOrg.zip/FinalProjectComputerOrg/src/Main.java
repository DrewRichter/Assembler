import java.io.FileReader;
import java.util.*;

import java.io.*;
import java.util.concurrent.Callable;


public class Main {






    public static void main(String[] args) {

        int programCounter=0;

        HashMap Commands = new HashMap<>(); // Value will be funct for R's and opcode for I's and J's
        Commands.put("add",32);
        Commands.put("addi",8);
        Commands.put("and",36);
        Commands.put("j", 2);
        Commands.put("ori",13);
        Commands.put("beq",4);
        Commands.put("bne",5);
        Commands.put("slt",42);
        Commands.put("sll",0);
        Commands.put("addu",33);
        HashMap Registers = new HashMap<>(28);
        Registers.put("$zero",0);
        Registers.put("$at", 1);
        Registers.put("$v0", 2);
        Registers.put("$v1", 3);
        Registers.put("$a0", 4);
        Registers.put("$a1",5);
        Registers.put("$a2",6);
        Registers.put("$a3",7);
        Registers.put("$t0",8);
        Registers.put("$t1",9);
        Registers.put("$t2",10);
        Registers.put("$t3",11);
        Registers.put("$t4",12);
        Registers.put("$t5",13);
        Registers.put("$t6",14);
        Registers.put("$t7",15);
        Registers.put("$s0",16);
        Registers.put("$s1",17);
        Registers.put("$s2", 18);
        Registers.put("$s3", 19);
        Registers.put("s4",20);
        Registers.put("$s5",21);
        Registers.put("$s6",22);
        Registers.put("$s7",23);
        Registers.put("$t8",24);
        Registers.put("$t9",25);
        Registers.put("$k0",26);
        Registers.put("$k1",27);
        HashMap Labels = new HashMap<>();//Stores labels with their addresses






         class MipsCommandsR{
             final int opcode=0;
             int rs;
             int rt;
             int rd;
             int shamt=0;
             int funct;
             int finalCode;
             String name;
             MipsCommandsR(String name, String RD, String RS, String RT  ){ //for sll shamt will be rt 2nd spot

                 this.name=name;
                 if (name.equals("sll")){
                     shamt=Integer.parseInt(RT);
                     rs=0;
                     rt=(int)Registers.get(RS);

                 }
                 else{this.rs=(int)Registers.get(RS); this.rt=(int)Registers.get(RT);}


                 this.rd=(int)Registers.get(RD);

                 this.funct=(int)Commands.get(name);


                 finalCode=this.CalculateFinalCode();


             }

             int CalculateFinalCode(){

                 double finalCodeDecimal=  funct+shamt*Math.pow(2,6)+rd*Math.pow(2,11)+rt*Math.pow(2,16)+rs*Math.pow(2,21)+opcode*Math.pow(2,26);

                int finalCodeBinary=(int)finalCodeDecimal;
                return finalCodeBinary;

             }
             String getCode(){
                 String outputString=Integer.toBinaryString(finalCode);
                 int length=outputString.length();
                 for(int i=0;i<(32-length);i++){
                     outputString="0"+outputString;
                 }
                 return outputString;
             }

         }
         class MipsCommandsI{
             int opcode;
             int rs;
             int rt;
             int immediate;
             int finalCode;
             String name;
             MipsCommandsI( String name, String RS, String RT, String Immediate ){
                 this.name=name;
                 this.opcode=(int)Commands.get(name);
                 this. rs=(int)Registers.get(RS);
                 this.rt=(int)Registers.get(RT);

                 this. immediate=Integer.parseInt(Immediate);

                 finalCode=this.CalculateFinalCode();
             }

             int CalculateFinalCode(){
                 double finalCodeDecimal=immediate+rt*Math.pow(2,16)+rs*Math.pow(2,21)+opcode*Math.pow(2,26);
                 int finalCodeBinary= (int)finalCodeDecimal;
                 return finalCodeBinary;
             }
             String getCode(){


                 String outputString=Integer.toBinaryString(finalCode);
                 int length=outputString.length();
                 for(int i=0;i<(32-length);i++){
                     outputString="0"+outputString;
                 }
                 return outputString;
         }
         }
         class MipsCommandsJ{
             int opcode;
             int address;
             String name;
             int finalCode;
             MipsCommandsJ( String name, String Address ){
                 this.name=name;
                 this.opcode=(int)Commands.get(name);
                 this.address=(int)Labels.get(Address);

                 finalCode=this.CalculateFinalCode();
             }
             int CalculateFinalCode(){
                 double finalCodeDecimal=address+opcode*Math.pow(2,26);
                 int finalCodeBinary= (int) finalCodeDecimal;
                 return finalCodeBinary;
             }
             String getCode(){
                 String outputString=Integer.toBinaryString(finalCode);
                 int length=outputString.length();
                 for(int i=0;i<(32-length);i++){
                     outputString="0"+outputString;
                 }
                 return outputString;
             }
         }

        //HashMap ImplementInstructions = new HashMap<>(28);
        //ImplementInstructions.put("addi",new MipsCommandsI(current, str1,str2,str3));

        String fileName="prog.asm";

         String line;
         String outFileName="prog.txt";

        try {
            FileWriter fileWriter= new FileWriter(outFileName);

            FileReader fileReader =
                    new FileReader(fileName);


            BufferedReader bufferedReader =
                    new BufferedReader(fileReader);


            while((line = bufferedReader.readLine()) != null){

                 if(line.isEmpty()){continue;}





                else{programCounter+=4;
                Labels.put(line,programCounter);}
                if(line.contains(":")){
                    Labels.put(line.split(":")[0],programCounter);
                }
            }
             fileReader =
                    new FileReader(fileName);


             bufferedReader =
                    new BufferedReader(fileReader);


            while((line = bufferedReader.readLine()) != null) {

                if(line.isEmpty()){continue;}



                String [] MainArray=line.split("[\\s:,]+");



               Iterator MainIterator = Arrays.asList(MainArray).iterator();
                 String current=(String) MainIterator.next();

                try{
                 if( Labels.containsKey(current)) {

                     current=(String)MainIterator.next();


                 }}
                 catch (NoSuchElementException ex){break;}

                 if(current.equals("move")){
                     MipsCommandsR command = new MipsCommandsR("addu",(String) MainIterator.next(),"$zero",(String)MainIterator.next());
                     fileWriter.write(command.getCode()+"\n");
                     System.out.println(command.getCode()+" "+line);
                     continue;
                 }
                 if(current.equals("blt")){


                     MipsCommandsR command1= new MipsCommandsR("slt","$at",(String)MainIterator.next(),(String)MainIterator.next());
                     fileWriter.write(command1.getCode()+"\n");
                     System.out.println(command1.getCode()+" "+line);
                     MipsCommandsI command= new MipsCommandsI("bne","$at","$zero",Integer.toString((int)Labels.get(MainIterator.next())));
                     fileWriter.write(command.getCode()+"\n");
                     System.out.println(command.getCode()+" "+line);
                     continue;
                 }
                 if(current.equals("add")|| current.equals("slt")||current.equals("sll")||current.equals("and")){

                      MipsCommandsR command= new MipsCommandsR(current,(String)MainIterator.next(),(String)MainIterator.next(),(String)MainIterator.next());
                      fileWriter.write(command.getCode()+"\n");
                      System.out.println(command.getCode()+" "+line);
                }
                else if(current.equals("addi") || current.equals("ori")){

                    MipsCommandsI command= new MipsCommandsI(current,(String)MainIterator.next(),(String)MainIterator.next(),(String)MainIterator.next());
                    fileWriter.write(command.getCode()+"\n");
                    System.out.println(command.getCode()+" "+line);

                 }
                 else if(current.equals("j")){

                     MipsCommandsJ command = new MipsCommandsJ(current,(String)MainIterator.next());
                     fileWriter.write(command.getCode()+"\n");
                     System.out.println(command.getCode()+" "+line);
                 }
                 else if(current.equals("beq")||current.equals("bne")){

                     String arg1=(String)MainIterator.next();

                     String arg2=(String)MainIterator.next();


                     int address=((((int)Labels.get(line)+4)-(int)Labels.get(MainIterator.next()))/4)*-1;
                     if(address<0){
                         address=address+65536;
                     }

                     MipsCommandsI command= new MipsCommandsI(current,arg1,arg2,Integer.toString(address));
                     fileWriter.write(command.getCode()+"\n");
                     System.out.println(command.getCode()+" "+line);

                 }
                 else{


                 }

            }


            bufferedReader.close();
            fileWriter.close();

        }
        catch(FileNotFoundException ex) {}

        catch(IOException ex) {}




               }

    }

